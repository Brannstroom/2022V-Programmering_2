package opggave_2_2;

public class Gravity {

    protected double calculateWeightOnMoon(double weight) {
        return weight*0.165;
    }

}
