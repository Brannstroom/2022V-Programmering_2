package oppgave_2_3;

public class oppgave_2_3 {

    public static void main(String[] args) {

        Planet planet = new Planet("Mars", 3889, 6.39E23);
        System.out.println(planet);
    }
}
